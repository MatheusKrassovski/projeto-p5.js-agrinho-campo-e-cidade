function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(135, 206, 235); // céu azul

  // Campo (lado esquerdo)
  drawField(0, 0, width / 2, height);

  // Cidade (lado direito)
  drawCity(width / 2, 0, width / 2, height);

  // Linha divisória
  stroke(0);
  strokeWeight(4);
  line(width / 2, 0, width / 2, height);
}

function drawField(x, y, w, h) {
  // Grama
  noStroke();
  fill(34, 139, 34);
  rect(x, y + h * 0.7, w, h * 0.3);

  // Árvores simples
  for (let i = 30; i < w; i += 80) {
    drawTree(x + i, y + h * 0.7);
  }
}

function drawTree(tx, ty) {
  // Tronco
  fill(101, 67, 33);
  rect(tx - 10, ty - 40, 20, 40);

  // Folhas
  fill(34, 139, 34);
  ellipse(tx, ty - 60, 50, 50);
}

function drawCity(x, y, w, h) {
  // Chão (rua)
  noStroke();
  fill(100);
  rect(x, y + h * 0.8, w, h * 0.2);

  // Prédios
  fill(150);
  for (let i = x + 20; i < x + w - 50; i += 70) {
    let buildingHeight = random(h * 0.3, h * 0.7);
    rect(i, y + h * 0.8 - buildingHeight, 50, buildingHeight);

    // Janelas iluminadas
    fill(255, 255, 100);
    for (let wy = y + h * 0.8 - buildingHeight + 10; wy < y + h * 0.8 - 10; wy += 20) {
      for (let wx = i + 10; wx < i + 40; wx += 20) {
        if (random() > 0.5) {
          rect(wx, wy, 10, 10);
        }
      }
    }
    fill(150);
  }
}